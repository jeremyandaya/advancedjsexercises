var x = ["crazy", 4, "dumb", "smart"]
var y = ["short", 8, "tall", "medium"]
var atts = [x, y]

function arrayloop(){
	for (var i = 0; i >= atts.length; i+=1) {
		x+y;
		console.log(i);
	};
}

arrayloop()

